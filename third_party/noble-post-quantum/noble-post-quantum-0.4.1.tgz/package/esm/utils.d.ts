import { type TypedArray, abytes, concatBytes, randomBytes as randb, utf8ToBytes } from '@noble/hashes/utils';
export declare const ensureBytes: typeof abytes;
export declare const randomBytes: typeof randb;
export { concatBytes, utf8ToBytes };
export declare function equalBytes(a: Uint8Array, b: Uint8Array): boolean;
/** Generic interface for signatures. Has keygen, sign and verify. */
export type Signer = {
    signRandBytes: number;
    keygen: (seed: Uint8Array) => {
        secretKey: Uint8Array;
        publicKey: Uint8Array;
    };
    sign: (secretKey: Uint8Array, msg: Uint8Array, random?: Uint8Array) => Uint8Array;
    verify: (publicKey: Uint8Array, msg: Uint8Array, sig: Uint8Array) => boolean;
};
export interface Coder<F, T> {
    encode(from: F): T;
    decode(to: T): F;
}
export interface BytesCoder<T> extends Coder<T, Uint8Array> {
    encode: (data: T) => Uint8Array;
    decode: (bytes: Uint8Array) => T;
}
export type BytesCoderLen<T> = BytesCoder<T> & {
    bytesLen: number;
};
type UnCoder<T> = T extends BytesCoder<infer U> ? U : never;
type SplitOut<T extends (number | BytesCoderLen<any>)[]> = {
    [K in keyof T]: T[K] extends number ? Uint8Array : UnCoder<T[K]>;
};
export declare function splitCoder<T extends (number | BytesCoderLen<any>)[]>(...lengths: T): BytesCoder<SplitOut<T>> & {
    bytesLen: number;
};
export declare function vecCoder<T>(c: BytesCoderLen<T>, vecLen: number): BytesCoderLen<T[]>;
export declare function cleanBytes(...list: (TypedArray | TypedArray[])[]): void;
export declare function getMask(bits: number): number;
export declare const EMPTY: Uint8Array;
export declare function getMessage(msg: Uint8Array, ctx?: Uint8Array): Uint8Array;
export declare function getMessagePrehash(hashName: string, msg: Uint8Array, ctx?: Uint8Array): Uint8Array;
//# sourceMappingURL=utils.d.ts.map