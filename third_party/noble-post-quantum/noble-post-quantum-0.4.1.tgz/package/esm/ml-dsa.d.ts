import { type Signer } from './utils.ts';
/** Various lattice params. */
export type DSAParam = {
    K: number;
    L: number;
    D: number;
    GAMMA1: number;
    GAMMA2: number;
    TAU: number;
    ETA: number;
    OMEGA: number;
};
/** Internal params for different versions of ML-DSA  */
export declare const PARAMS: Record<string, DSAParam>;
/** Signer API, containing internal methods */
export type SignerWithInternal = Signer & {
    internal: Signer;
};
/** ML-DSA-44 for 128-bit security level. Not recommended after 2030, as per ASD. */
export declare const ml_dsa44: SignerWithInternal;
/** ML-DSA-65 for 192-bit security level. Not recommended after 2030, as per ASD. */
export declare const ml_dsa65: SignerWithInternal;
/** ML-DSA-87 for 256-bit security level. OK after 2030, as per ASD. */
export declare const ml_dsa87: SignerWithInternal;
//# sourceMappingURL=ml-dsa.d.ts.map