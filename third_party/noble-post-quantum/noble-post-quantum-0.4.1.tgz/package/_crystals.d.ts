import type { TypedArray } from '@noble/hashes/utils';
import { type BytesCoderLen, type Coder } from './utils.ts';
export type XOF = (seed: Uint8Array, blockLen?: number) => {
    stats: () => {
        calls: number;
        xofs: number;
    };
    get: (x: number, y: number) => () => Uint8Array;
    clean: () => void;
};
/** CRYSTALS (ml-kem, ml-dsa) options */
export type CrystalOpts<T extends TypedArray> = {
    newPoly: TypedCons<T>;
    N: number;
    Q: number;
    F: number;
    ROOT_OF_UNITY: number;
    brvBits: number;
    isKyber: boolean;
};
export type TypedCons<T extends TypedArray> = (n: number) => T;
export declare const genCrystals: <T extends TypedArray>(opts: CrystalOpts<T>) => {
    mod: (a: number, modulo?: number) => number;
    smod: (a: number, modulo?: number) => number;
    nttZetas: T;
    NTT: {
        encode: (r: T) => T;
        decode: (r: T) => T;
    };
    bitsCoder: (d: number, c: Coder<number, number>) => BytesCoderLen<T>;
};
export declare const XOF128: XOF;
export declare const XOF256: XOF;
//# sourceMappingURL=_crystals.d.ts.map